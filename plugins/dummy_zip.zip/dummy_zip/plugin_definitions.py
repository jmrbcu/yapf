# -*- coding: utf-8 -*-
__author__ = "jmrbcu"
import logging
from plugin_manager import Plugin, extends

logger = logging.getLogger(__name__)


class DummyZipPlugin(Plugin):

    id = "dummy_zip"
    name = "Dummy Zip"
    version = "0.1"
    description = "Just a dummy plugin in a zip file"
    platform = "all"
    author = ['Jon Doe']
    author_email = "jon@doe.com"
    depends = []
    enabled = True
